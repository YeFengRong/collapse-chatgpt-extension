# Collapse ChatGPT Replies — Chrome Extension

One-click toggle to **collapse all ChatGPT replies** (assistant messages) on the **current tab only**, while **keeping your own messages visible**. Click the extension icon again to restore everything.

## Install

1. Download the zip from ChatGPT and extract it somewhere convenient.
2. Open **chrome://extensions** in Chrome (or Chromium/Edge).
3. Turn on **Developer mode** (top-right).
4. Click **Load unpacked** and select the extracted folder.

> Works on both **chatgpt.com** and **chat.openai.com**.

## Usage

- Open a ChatGPT conversation.
- Click the extension's toolbar icon:
  - First click → **collapses** assistant replies.
  - Second click → **restores** them.
- The effect is **scoped to the current tab** and does not affect other tabs.

## Notes

- This extension injects a small stylesheet and toggles a class on the page root (`html`), so it’s resilient to DOM changes and automatically applies to new assistant messages.
- If you don't see any change on non-ChatGPT pages, that's expected—there's nothing to collapse.
