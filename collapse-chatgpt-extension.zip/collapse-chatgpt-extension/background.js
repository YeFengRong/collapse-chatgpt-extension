// background.js (service worker)
chrome.action.onClicked.addListener(async (tab) => {
  if (!tab || !tab.id) return;

  // Try to toggle first (content script may already be injected)
  try {
    const resp = await chrome.tabs.sendMessage(tab.id, { type: "TOGGLE_COLLAPSE_ASSISTANT" });
    // Optionally, update badge text to reflect state
    if (resp && typeof resp.collapsed === "boolean") {
      await chrome.action.setBadgeText({ tabId: tab.id, text: resp.collapsed ? "ON" : "" });
    }
    return;
  } catch (e) {
    // No content script yet; fall through to inject
  }

  // Inject content script into the active tab, then toggle
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["content.js"]
    });
    const resp = await chrome.tabs.sendMessage(tab.id, { type: "TOGGLE_COLLAPSE_ASSISTANT" });
    if (resp && typeof resp.collapsed === "boolean") {
      await chrome.action.setBadgeText({ tabId: tab.id, text: resp.collapsed ? "ON" : "" });
    }
  } catch (err) {
    // Could not inject (likely due to lack of permissions or restricted page)
    console.warn("Collapse ChatGPT Replies: failed to inject content script", err);
  }
});
