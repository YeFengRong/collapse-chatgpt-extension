// content.js
(() => {
  const STATE_KEY = "__cgCollapseState";
  const STYLE_ID = "cg-collapse-style";
  const CLASS_ON = "cg-assistant-collapsed";

  function ensureStyle() {
    if (document.getElementById(STYLE_ID)) return;
    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = `
/* Collapse assistant (ChatGPT) turns when toggled ON */
html.${CLASS_ON} [data-message-author-role="assistant"] { display: none !important; }
html.${CLASS_ON} [data-author-role="assistant"] { display: none !important; }
html.${CLASS_ON} [data-testid="assistant-turn"] { display: none !important; }
/* Fallbacks in case the role is on a child element */
html.${CLASS_ON} article:has([data-message-author-role="assistant"]) { display: none !important; }
html.${CLASS_ON} div:has(> [data-message-author-role="assistant"]) { display: none !important; }
    `.trim();
    document.documentElement.appendChild(style);
  }

  function setCollapsed(on) {
    ensureStyle();
    document.documentElement.classList.toggle(CLASS_ON, on);
    window[STATE_KEY] = on;
  }

  function toggle() {
    setCollapsed(!window[STATE_KEY]);
  }

  // Message listener (register once)
  if (!window.__cgToggleRegistered) {
    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
      if (msg && msg.type === "TOGGLE_COLLAPSE_ASSISTANT") {
        toggle();
        sendResponse({ collapsed: !!window[STATE_KEY] });
        return true;
      }
      return false;
    });
    window.__cgToggleRegistered = true;
  }
})();
